const express = require("express");
const cors = require("cors");
const path = require("path");
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

let prices = [
  { crop: "Paddy", price: 2280, market: "Local Mandi", date: new Date().toISOString().slice(0,10) },
  { crop: "Cotton", price: 7120, market: "Local Mandi", date: new Date().toISOString().slice(0,10) }
];

app.get("/api/health", (req,res) => res.json({ok:true, service:"Smart Farmer Assistant"}));

app.get("/api/prices", (req,res) => res.json(prices));

app.post("/api/prices", (req,res) => {
  const { crop, price, market } = req.body;
  if (!["Paddy","Cotton"].includes(crop) || !price || !market) {
    return res.status(400).json({error:"crop, price and market are required"});
  }
  const item = { crop, price:Number(price), market, date:new Date().toISOString().slice(0,10) };
  prices.unshift(item);
  prices = prices.slice(0,50);
  res.status(201).json(item);
});

/* Weather proxy: browser calls this server, which calls Open-Meteo.
   No API key is required for Open-Meteo's public forecast endpoint. */
app.get("/api/weather", async (req,res) => {
  const {lat, lon} = req.query;
  if (!lat || !lon) return res.status(400).json({error:"lat and lon are required"});
  try {
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${encodeURIComponent(lat)}&longitude=${encodeURIComponent(lon)}&current=temperature_2m,relative_humidity_2m,precipitation,rain,weather_code,wind_speed_10m&hourly=precipitation_probability&forecast_days=1&timezone=auto`;
    const response = await fetch(url);
    if (!response.ok) throw new Error("Weather provider error");
    res.json(await response.json());
  } catch (e) {
    res.status(502).json({error:"Weather service unavailable"});
  }
});

/* AI endpoint. Add an AI provider in production and keep its key in .env.
   The demo fallback keeps the website functional without exposing secrets. */
app.post("/api/assistant", async (req,res) => {
  const {message, language="en"} = req.body;
  if (!message) return res.status(400).json({error:"message is required"});
  const text = message.toLowerCase();
  let reply;
  if (language === "te") {
    if (text.includes("నీరు") || text.includes("నీళ్లు"))
      reply = "నీరు పెట్టే ముందు నేల తేమ, పంట దశ మరియు వర్ష సూచనను చూడండి. పంట దశ చెబితే మరింత ప్రత్యేకంగా సూచించగలను.";
    else if (text.includes("వరి")) reply = "వరి పంటలో నీటి నిర్వహణ పంట దశ మరియు నేల పరిస్థితిపై ఆధారపడి ఉంటుంది. అధికంగా నీరు నిల్వ చేయకుండా స్థానిక వ్యవసాయ సిఫార్సులు పాటించండి.";
    else if (text.includes("పత్తి")) reply = "పత్తిలో నేల తేమ, పంట దశ మరియు పురుగు లక్షణాలను గమనించండి. లక్షణాలు వివరించండి.";
    else reply = "పంట పేరు, పంట దశ, నేల పరిస్థితి మరియు సమస్యను చెప్పండి. దానికి అనుగుణంగా సలహా ఇస్తాను.";
  } else {
    if (/irrig|water|moisture/.test(text))
      reply = "Before irrigation, check soil moisture, crop stage and the rainfall forecast. Tell me the crop stage for a more specific plan.";
    else if (/paddy|rice/.test(text))
      reply = "For paddy, irrigation depends on crop stage, soil condition and expected rainfall. Avoid unnecessary watering before rain.";
    else if (/cotton/.test(text))
      reply = "For cotton, monitor soil moisture, crop stage and pest symptoms. Describe the symptom for a first-level checklist.";
    else reply = "Tell me your crop, crop stage, soil condition and the problem you are seeing. I can guide you step by step.";
  }
  res.json({reply, demo:true});
});

app.get("*", (req,res) => res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT, () => console.log(`Smart Farmer Assistant running at http://localhost:${PORT}`));
